library(mice) 
library(missForest) 
library(class)
library(caret)
library(imputeR) #for Rmse

irisdata <- iris
trdata <- as.matrix(irisdata[,-5])


#iris 15%
set.seed(123)
myrandom <- function(x,pc)
{
  index <- sample(1:nrow(x),nrow(x)*(pc/100))
  if(pc %% 2 == 0)
  {
    
    x[index, 2] <- NA     #Sepal Length
  }
  
  else
  {
    x[index, 4] <- NA     #Petal Length
  }
  return(x)
}

iris.15pc <- myrandom(irisdata[,-5], 15)  #excluding species from missing values
mis <- as.matrix(iris.15pc)


#Method 1: Imputing using PMM:-
imputed_Data <- mice(iris.15pc, m=5, maxit = 50, method = 'pmm', seed = 200)

completeData <- complete(imputed_Data,1)

#Creating Training and Test data for knn
train <- irisdata[, -5]
test <- completeData
cl <- irisdata[,5]


#Applying knn and predicting acurracy,precision,recall  [k= sqrt(N)/2, N=150 for iris dataset]
pred <- knn(train,test,cl,k=6)
conf <- confusionMatrix(pred,cl,mode="prec_recall")
conf

#rmse error
imp <- as.matrix(completeData)
rmse.error <- Rmse(imp, mis, trdata, norm = FALSE)



#Method 2: rf
imputed_Data2 <- mice(iris.15pc, m=5, maxit = 50, method = 'rf', seed = 400)
completeData2 <- complete(imputed_Data2,1)

train2 <- irisdata[, -5]
test2 <- completeData2



#Applying knn and predicting acurracy,precision,recall  [k= sqrt(N)/2, N=150 for iris dataset]
pred2 <- knn(train2,test2,cl,k=6)
conf2 <- confusionMatrix(pred2,cl,mode="prec_recall")
conf2

#rmse 
imp2 <- as.matrix(completeData2)
rmse.error2 <- Rmse(imp2, mis, trdata, norm = FALSE)
rmse.error2


#Bayesian Linear Regression
imputed_Data3 <- mice(iris.15pc, m=5, maxit = 50, method = 'norm', seed = 600)
completeData3 <- complete(imputed_Data3,1)

train3 <- irisdata[, -5]
test3 <- completeData3



#Applying knn and predicting acurracy,precision,recall  [k= sqrt(N)/2, N=150 for iris dataset]
pred3 <- knn(train3,test3,cl,k=6)
conf3 <- confusionMatrix(pred3,cl,mode="prec_recall")
conf3

#rmse
imp3 <- as.matrix(completeData3)
rmse.error3 <- Rmse(imp3, mis, trdata, norm = FALSE)
rmse.error3
